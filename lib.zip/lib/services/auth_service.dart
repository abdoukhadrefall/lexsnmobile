import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/user_model.dart';
import 'api_client.dart';

// State de l'utilisateur connecté
final authStateProvider = AsyncNotifierProvider<AuthNotifier, UserModel?>(() {
  return AuthNotifier();
});

class AuthNotifier extends AsyncNotifier<UserModel?> {
  final _storage = const FlutterSecureStorage();

  @override
  Future<UserModel?> build() async {
    // Vérifier le token au démarrage
    final token = await _storage.read(key: 'auth_token');
    if (token == null) return null;

    try {
      final api = ref.read(apiClientProvider);
      final data = await api.getDashboard();
      if (data['user'] != null) {
        return UserModel.fromJson(data['user'] as Map<String, dynamic>);
      }
    } catch (_) {
      await _storage.delete(key: 'auth_token');
    }
    return null;
  }

  Future<void> login(String email, String password) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final api = ref.read(apiClientProvider);
      final data = await api.login(email, password);

      // Stocker le token
      await _storage.write(key: 'auth_token', value: data['token'] as String);

      return UserModel.fromJson(data['user'] as Map<String, dynamic>);
    });
  }

  Future<void> logout() async {
    final api = ref.read(apiClientProvider);
    await api.logout();
    state = const AsyncData(null);
  }
}