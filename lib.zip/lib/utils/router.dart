import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lexsn_mobile/screens/audiences/audiences_screen.dart';
import 'package:lexsn_mobile/screens/factures/factures_screen.dart';

import '../services/auth_service.dart';
import '../screens/auth/login_screen.dart';
import '../screens/dashboard/dashboard_screen.dart';
import '../screens/dossiers/dossiers_list_screen.dart';
import '../screens/dossiers/dossier_detail_screen.dart';
import '../screens/dossiers/dossier_form_screen.dart';
import '../screens/audiences/audiences_screen.dart';
import '../screens/audiences/audiences_form_screen.dart';
import '../screens/clients/clients_screen.dart';
import '../screens/clients/client_detail_screen.dart';
import '../screens/clients/client_form_screen.dart';
import '../screens/factures/factures_screen.dart';
import '../screens/factures/facture_detail_screen.dart';
import '../widgets/main_shell.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: '/dashboard',
    debugLogDiagnostics: false,
    redirect: (context, state) {
      final isLoggedIn = authState.value != null;
      final isLoginPage = state.matchedLocation == '/login';

      if (!isLoggedIn && !isLoginPage) return '/login';
      if (isLoggedIn && isLoginPage) return '/dashboard';
      return null;
    },
    routes: [
      // Auth
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),

      // Shell avec navigation bar
      ShellRoute(
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          // Dashboard
          GoRoute(
            path: '/dashboard',
            name: 'dashboard',
            builder: (context, state) => const DashboardScreen(),
          ),

          // Dossiers
          GoRoute(
            path: '/dossiers',
            name: 'dossiers',
            builder: (context, state) => const DossiersListScreen(),
            routes: [
              GoRoute(
                path: 'nouveau',
                name: 'dossier-nouveau',
                builder: (context, state) => const DossierFormScreen(),
              ),
              GoRoute(
                path: ':id',
                name: 'dossier-detail',
                builder: (context, state) => DossierDetailScreen(
                  dossierId: int.parse(state.pathParameters['id']!),
                ),
                routes: [
                  GoRoute(
                    path: 'modifier',
                    name: 'dossier-modifier',
                    builder: (context, state) => DossierFormScreen(
                      dossierId: int.parse(state.pathParameters['id']!),
                    ),
                  ),
                  GoRoute(
                    path: 'audience',
                    name: 'audience-nouveau',
                    builder: (context, state) => AudienceFormScreen(
                      dossierId: int.parse(state.pathParameters['id']!),
                    ),
                  ),
                ],
              ),
            ],
          ),

          // Audiences
          GoRoute(
            path: '/audiences',
            name: 'audiences',
            builder: (context, state) => const AudiencesScreen(),
            routes: [
              GoRoute(
                path: ':id/modifier',
                name: 'audience-modifier',
                builder: (context, state) => AudienceFormScreen(
                  audienceId: int.parse(state.pathParameters['id']!),
                ),
              ),
            ],
          ),

          // Clients
          GoRoute(
            path: '/clients',
            name: 'clients',
            builder: (context, state) => const ClientsScreen(),
            routes: [
              GoRoute(
                path: 'nouveau',
                name: 'client-nouveau',
                builder: (context, state) => const ClientFormScreen(),
              ),
              GoRoute(
                path: ':id',
                name: 'client-detail',
                builder: (context, state) => ClientDetailScreen(
                  clientId: int.parse(state.pathParameters['id']!),
                ),
              ),
            ],
          ),

          // Factures
          GoRoute(
            path: '/factures',
            name: 'factures',
            builder: (context, state) => const FacturesScreen(),
            routes: [
              GoRoute(
                path: ':id',
                name: 'facture-detail',
                builder: (context, state) => FactureDetailScreen(
                  factureId: int.parse(state.pathParameters['id']!),
                ),
              ),
            ],
          ),
        ],
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 48, color: Colors.red),
            const SizedBox(height: 16),
            Text('Page introuvable : ${state.matchedLocation}'),
            TextButton(
              onPressed: () => context.go('/dashboard'),
              child: const Text('Retour au tableau de bord'),
            ),
          ],
        ),
      ),
    ),
  );
});