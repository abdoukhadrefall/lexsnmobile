class DossierModel {
  final int id;
  final String reference;
  final String intitule;
  final String typeAffaire;
  final String statut;
  final String? juridiction;
  final String? numeroParquet;
  final String? description;
  final String? partiesAdverses;
  final DateTime dateOuverture;
  final DateTime? dateCloture;
  final double? honorairesPrevus;
  final ClientResume client;
  final AvocatResume avocat;
  final AudienceResume? prochaineAudience;
  final int audiencesCount;
  final int documentsCount;

  const DossierModel({
    required this.id,
    required this.reference,
    required this.intitule,
    required this.typeAffaire,
    required this.statut,
    this.juridiction,
    this.numeroParquet,
    this.description,
    this.partiesAdverses,
    required this.dateOuverture,
    this.dateCloture,
    this.honorairesPrevus,
    required this.client,
    required this.avocat,
    this.prochaineAudience,
    this.audiencesCount = 0,
    this.documentsCount = 0,
  });

  static const Map<String, String> typesLabels = {
    'civil': 'Civil',
    'penal': 'Pénal',
    'commercial': 'Commercial',
    'administratif': 'Administratif',
    'social': 'Social / Travail',
    'foncier': 'Foncier',
    'famille': 'Famille',
    'autre': 'Autre',
  };

  static const Map<String, String> statutsLabels = {
    'ouvert': 'Ouvert',
    'en_cours': 'En cours',
    'suspendu': 'Suspendu',
    'clos': 'Clos',
    'archive': 'Archivé',
  };
 static double? _parseDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is num) return value.toDouble();
    if (value is String) {
      final cleaned = value.replaceAll(RegExp(r'[^\d.-]'), '');
      return double.tryParse(cleaned);
    }
    return null;
  }
  String get typeLabel => typesLabels[typeAffaire] ?? typeAffaire;
  String get statutLabel => statutsLabels[statut] ?? statut;

  factory DossierModel.fromJson(Map<String, dynamic> json) {
    return DossierModel(
      id: json['id'] as int,
      reference: json['reference'] as String,
      intitule: json['intitule'] as String,
      typeAffaire: json['type_affaire'] as String,
      statut: json['statut'] as String,
      juridiction: json['juridiction'] as String?,
      numeroParquet: json['numero_parquet'] as String?,
      description: json['description'] as String?,
      partiesAdverses: json['parties_adverses'] as String?,
      dateOuverture: DateTime.parse(json['date_ouverture'] as String),
      dateCloture: json['date_cloture'] != null
          ? DateTime.parse(json['date_cloture'] as String)
          : null,
          honorairesPrevus: json['honoraires_prevus'] != null 
    ? double.tryParse(json['honoraires_prevus'].toString()) 
    : null,
      client: ClientResume.fromJson(json['client'] as Map<String, dynamic>),
      avocat: AvocatResume.fromJson(json['avocat'] as Map<String, dynamic>),
      prochaineAudience: json['prochaine_audience'] != null
          ? AudienceResume.fromJson(json['prochaine_audience'] as Map<String, dynamic>)
          : null,
      audiencesCount: json['audiences_count'] as int? ?? 0,
      documentsCount: json['documents_count'] as int? ?? 0,
    );
  }
}

class ClientResume {
  final int id;
  final String nom;
  final String? prenom;
  final String? telephone;
  final String type;

  const ClientResume({
    required this.id,
    required this.nom,
    this.prenom,
    this.telephone,
    required this.type,
  });

  String get nomComplet => prenom != null ? '$nom $prenom' : nom;
  String get initiales {
    final parts = nomComplet.split(' ');
    return parts.map((p) => p.isNotEmpty ? p[0].toUpperCase() : '').take(2).join();
  }

  factory ClientResume.fromJson(Map<String, dynamic> json) {
    return ClientResume(
      id: json['id'] as int,
      nom: json['nom'] as String,
      prenom: json['prenom'] as String?,
      telephone: json['telephone'] as String?,
      type: json['type'] as String? ?? 'personne_physique',
    );
  }
}

class AvocatResume {
  final int id;
  final String nom;
  final String prenom;

  const AvocatResume({required this.id, required this.nom, required this.prenom});

  String get nomComplet => '$prenom $nom';

  factory AvocatResume.fromJson(Map<String, dynamic> json) {
    return AvocatResume(
      id: json['id'] as int,
      nom: json['nom'] as String,
      prenom: json['prenom'] as String,
    );
  }
}

class AudienceResume {
  final int id;
  final String objet;
  final DateTime dateHeure;
  final String statut;

  const AudienceResume({
    required this.id,
    required this.objet,
    required this.dateHeure,
    required this.statut,
  });

  factory AudienceResume.fromJson(Map<String, dynamic> json) {
    return AudienceResume(
      id: json['id'] as int,
      objet: json['objet'] as String,
      dateHeure: DateTime.parse(json['date_heure'] as String),
      statut: json['statut'] as String,
    );
  }

  bool? get estDansLes48h => null;
  
}