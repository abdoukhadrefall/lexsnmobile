// ─── Audience ──────────────────────────────────────────────────────────────

class AudienceModel {
  final int id;
  final int dossierId;
  final String dossierReference;
  final String dossierIntitule;
  final String clientNom;
  final String objet;
  final DateTime dateHeure;
  final String statut;
  final String? salle;
  final DateTime? dateRenvoi;
  final String? resultat;
  final bool rappelEnvoye;

  const AudienceModel({
    required this.id,
    required this.dossierId,
    required this.dossierReference,
    required this.dossierIntitule,
    required this.clientNom,
    required this.objet,
    required this.dateHeure,
    required this.statut,
    this.salle,
    this.dateRenvoi,
    this.resultat,
    this.rappelEnvoye = false,
  });

  static const Map<String, String> statutsLabels = {
    'planifiee': 'Planifiée',
    'tenue': 'Tenue',
    'renvoyee': 'Renvoyée',
    'annulee': 'Annulée',
  };

  String get statutLabel => statutsLabels[statut] ?? statut;

  bool get estDansLes48h {
    final diff = dateHeure.difference(DateTime.now());
    return diff.inHours <= 48 && diff.isNegative == false;
  }

  bool get estPassee => dateHeure.isBefore(DateTime.now());

  factory AudienceModel.fromJson(Map<String, dynamic> json) {
    final dossier = json['dossier'] as Map<String, dynamic>? ?? {};
    final client = dossier['client'] as Map<String, dynamic>? ?? {};

    return AudienceModel(
      id: json['id'] as int,
      dossierId: json['dossier_id'] as int,
      dossierReference: dossier['reference'] as String? ?? '',
      dossierIntitule: dossier['intitule'] as String? ?? '',
      clientNom: client['nom'] as String? ?? '',
      objet: json['objet'] as String,
      dateHeure: DateTime.parse(json['date_heure'] as String),
      statut: json['statut'] as String,
      salle: json['salle'] as String?,
      dateRenvoi: json['date_renvoi'] != null
          ? DateTime.parse(json['date_renvoi'] as String)
          : null,
      resultat: json['resultat'] as String?,
      rappelEnvoye: json['rappel_envoye'] as bool? ?? false,
    );
  }
}
