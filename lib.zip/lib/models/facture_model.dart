
import 'package:lexsn_mobile/models/audience_model.dart';
import 'package:lexsn_mobile/models/paiement_model.dart';

class FactureModel {
  final int id;
  final String numero;
  final String clientNom;
  final String dossierReference;
  final int dossierId;
  final DateTime dateEmission;
  final DateTime? dateEcheance;
  final double montantHt;
  final double tva;
  final double montantTtc;
  final double montantPaye;
  final String statut;
  final String? notes;
  final List<PaiementModel> paiements;

  const FactureModel({
    required this.id,
    required this.numero,
    required this.clientNom,
    required this.dossierReference,
    required this.dossierId,
    required this.dateEmission,
    this.dateEcheance,
    required this.montantHt,
    required this.tva,
    required this.montantTtc,
    required this.montantPaye,
    required this.statut,
    this.notes,
    this.paiements = const [],
  });

  double get resteAPayer => montantTtc - montantPaye;
  double get pctPaye => montantTtc > 0 ? (montantPaye / montantTtc) : 0;

  static const Map<String, String> statutsLabels = {
    'brouillon': 'Brouillon',
    'envoyee': 'Envoyée',
    'partiellement_payee': 'Partiel',
    'payee': 'Payée',
    'annulee': 'Annulée',
  };

  String get statutLabel => statutsLabels[statut] ?? statut;

  factory FactureModel.fromJson(Map<String, dynamic> json) {
    final client = json['client'] as Map<String, dynamic>? ?? {};
    final dossier = json['dossier'] as Map<String, dynamic>? ?? {};

    return FactureModel(
      id: json['id'] as int,
      numero: json['numero'] as String,
      clientNom: client['nom'] as String? ?? '',
      dossierReference: dossier['reference'] as String? ?? '',
      dossierId: json['dossier_id'] as int,
      dateEmission: DateTime.parse(json['date_emission'] as String),
      dateEcheance: json['date_echeance'] != null
          ? DateTime.parse(json['date_echeance'] as String)
          : null,
      montantHt: (json['montant_ht'] as num).toDouble(),
      tva: (json['tva'] as num).toDouble(),
      montantTtc: (json['montant_ttc'] as num).toDouble(),
      montantPaye: (json['montant_paye'] as num).toDouble(),
      statut: json['statut'] as String,
      notes: json['notes'] as String?,
      paiements: (json['paiements'] as List<dynamic>? ?? [])
          .map((p) => PaiementModel.fromJson(p as Map<String, dynamic>))
          .toList(),
    );
  }
}
