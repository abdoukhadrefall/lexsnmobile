import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../services/api_client.dart';
import '../../models/dossier_model.dart';
import '../../widgets/common_widgets.dart';
import '../../utils/theme.dart';

final dossiersProvider = FutureProvider.family<List<DossierModel>, Map<String, String>>(
  (ref, params) async {
    final data = await ref.read(apiClientProvider).getDossiers(
      q: params['q'],
      statut: params['statut'],
    );
    final items = data['data'] as List<dynamic>? ?? [];
    return items.map((e) => DossierModel.fromJson(e as Map<String, dynamic>)).toList();
  },
);

class DossiersListScreen extends ConsumerStatefulWidget {
  const DossiersListScreen({super.key});

  @override
  ConsumerState<DossiersListScreen> createState() => _DossiersListScreenState();
}

class _DossiersListScreenState extends ConsumerState<DossiersListScreen> {
  final _searchCtrl = TextEditingController();
  String _statut    = '';
  String _query     = '';

  Map<String, String> get _params => {
    if (_query.isNotEmpty) 'q': _query,
    if (_statut.isNotEmpty) 'statut': _statut,
  };

  @override
  Widget build(BuildContext context) {
    final dossiers = ref.watch(dossiersProvider(_params));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dossiers'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => context.go('/dossiers/nouveau'),
          ),
        ],
      ),
      body: Column(children: [

        // Recherche
        Container(
          color: LexSnTheme.surface,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Column(children: [
            TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Rechercher un dossier...',
                prefixIcon: const Icon(Icons.search, size: 18),
                suffixIcon: _query.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 16),
                        onPressed: () { setState(() { _searchCtrl.clear(); _query = ''; }); },
                      )
                    : null,
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
            const SizedBox(height: 10),

            // Filtres statuts
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _FilterChip(label: 'Tous', value: '', selected: _statut == '',
                    onTap: () => setState(() => _statut = '')),
                const SizedBox(width: 8),
                _FilterChip(label: 'Ouvert', value: 'ouvert', selected: _statut == 'ouvert',
                    onTap: () => setState(() => _statut = 'ouvert')),
                const SizedBox(width: 8),
                _FilterChip(label: 'En cours', value: 'en_cours', selected: _statut == 'en_cours',
                    onTap: () => setState(() => _statut = 'en_cours')),
                const SizedBox(width: 8),
                _FilterChip(label: 'Suspendu', value: 'suspendu', selected: _statut == 'suspendu',
                    onTap: () => setState(() => _statut = 'suspendu')),
                const SizedBox(width: 8),
                _FilterChip(label: 'Clos', value: 'clos', selected: _statut == 'clos',
                    onTap: () => setState(() => _statut = 'clos')),
              ]),
            ),
          ]),
        ),

        const Divider(height: 0),

        // Liste
        Expanded(
          child: dossiers.when(
            loading: () => const LexSnLoader(),
            error: (e, _) => LexSnError(
              message: 'Impossible de charger les dossiers',
              onRetry: () => ref.invalidate(dossiersProvider(_params)),
            ),
            data: (list) {
              if (list.isEmpty) {
                return const Center(child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.folder_off_outlined, size: 48, color: Color(0xFFD1D5DB)),
                    SizedBox(height: 12),
                    Text('Aucun dossier trouvé', style: TextStyle(color: Color(0xFF9CA3AF))),
                  ],
                ));
              }

              return RefreshIndicator(
                color: LexSnTheme.primary,
                onRefresh: () async => ref.invalidate(dossiersProvider(_params)),
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (_, i) => _DossierCard(dossier: list[i]),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final String value;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label, required this.value,
    required this.selected, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? LexSnTheme.primary : LexSnTheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? LexSnTheme.primary : LexSnTheme.border,
          ),
        ),
        child: Text(label, style: TextStyle(
          fontSize: 13, fontWeight: FontWeight.w500,
          color: selected ? Colors.white : const Color(0xFF374151),
        )),
      ),
    );
  }
}

class _DossierCard extends StatelessWidget {
  final DossierModel dossier;
  const _DossierCard({required this.dossier});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.go('/dossiers/${dossier.id}'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: LexSnTheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: LexSnTheme.border, width: 0.5),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFFF3F4F6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(dossier.reference, style: const TextStyle(
                fontSize: 11, fontWeight: FontWeight.w600,
                color: LexSnTheme.primary, fontFamily: 'monospace',
              )),
            ),
            const Spacer(),
            StatutBadge(statut: dossier.statut, styles: dossierStatutStyles),
          ]),

          const SizedBox(height: 8),
          Text(dossier.intitule, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: LexSnTheme.primary)),

          const SizedBox(height: 8),
          Row(children: [
            AvatarInitiales(initiales: dossier.client.initiales, size: 24,
              bg: LexSnTheme.successBg, fg: LexSnTheme.success),
            const SizedBox(width: 6),
            Expanded(child: Text(dossier.client.nomComplet,
              style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
              maxLines: 1, overflow: TextOverflow.ellipsis)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFFF3F4F6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(dossier.typeLabel, style: const TextStyle(
                fontSize: 11, color: Color(0xFF6B7280),
              )),
            ),
          ]),

          if (dossier.prochaineAudience != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: (dossier.prochaineAudience!.estDansLes48h ?? false)
                    ? LexSnTheme.dangerBg : LexSnTheme.infoBg,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(children: [
                Icon(Icons.calendar_today,
                  size: 12,
                  color: (dossier.prochaineAudience!.estDansLes48h ?? false)
                      ? LexSnTheme.danger : LexSnTheme.info),
                const SizedBox(width: 5),
                Text(
                  '${dossier.prochaineAudience!.objet} · '
                  '${formatDateHeure(dossier.prochaineAudience!.dateHeure)}',
                  style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w500,
                    color: (dossier.prochaineAudience!.estDansLes48h ?? false)
                        ? LexSnTheme.danger : LexSnTheme.info,
                  ),
                ),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}